package com.grupo10.app.rents;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppRentsApplicationTests {

	@Test
	void contextLoads() {
	}

}
